// Note: Skyrocket customizer script needs to be loaded directly by the custom control

import './src/js/nav-links';
import './src/js/vendor/skip-link-focus-fix';
